package game_recommendation_test;
import java.util.List;


public class Question
{
    public String quest;
    public SubQuestion[] dbChoices = new SubQuestion[100];
}
