package game_recommendation_test;


public class SubTag
{
    public String tag;
    public int val;
}
