package game_recommendation_test;


public class GuiWishlist
{
    public SubGame game_s;
    //public Text txt_nam;
    //public Button btn_steam;
}
