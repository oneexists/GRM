package game_recommendation_test;
import java.util.List;


public class GuiChoice
{
    //public Text txt_choice;
    public int num;
    public SubTag[] dbTags = new SubTag[100];
}
