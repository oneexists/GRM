package game_recommendation_test;
import java.util.*;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JTextPane;
import javax.swing.JLabel;


public class RecommendationManager
{
    public int qnum;
    public User user;
    public ApiManager api;
    public JFrame frame;
    public JLabel txtQuestion;
    //public Text txtResults;
    //public GameObject prefab_gui_result;
    //public List<GameObject> dbGos;
    public JButton[] dbBtnAnswers = new JButton[3];
    public JButton[] dbBtnGames = new JButton[5];
    public GuiChoice[] dbGuiChoices = new GuiChoice[100];
    public Question[] dbQuestions = new Question[1000];
    public GuiResult[] dbGuiResults = new GuiResult[5];
    
    
    public RecommendationManager()
    {
    	frame = new JFrame(); //creating instance of JFrame
		
		//**Question**//
    	txtQuestion = new JLabel();
    	txtQuestion.setBounds(250, 100, 400, 300);
		String wrd = "Would you rather:";
		txtQuestion.setText(wrd);
		//txtQuest = quest;
		frame.add(txtQuestion);
		
		
		//**Answers**//
		dbBtnAnswers[0] = new JButton("Answer 0"); //creating instance of JButton
		dbBtnAnswers[0].setBounds(250, 350, 300, 100); //x axis, y axis, width, height
		frame.add(dbBtnAnswers[0]); //adding button in JFrame

		dbBtnAnswers[1] = new JButton("Answer 1");
		dbBtnAnswers[1].setBounds(250, 470, 300, 100);
		frame.add(dbBtnAnswers[1]);

		dbBtnAnswers[2] = new JButton("Answer 2");
		dbBtnAnswers[2].setBounds(250, 590, 300, 100);
		frame.add(dbBtnAnswers[2]);

        
		//**Top 5 Game Recommendations**//
		dbBtnGames[0] = new JButton("Game 0");
		dbBtnGames[0].setBounds(800, 300, 400, 50);
		frame.add(dbBtnGames[0]);

		dbBtnGames[1] = new JButton("Game 1");
		dbBtnGames[1].setBounds(800, 350, 400, 50);
		frame.add(dbBtnGames[1]);
		
		dbBtnGames[2] = new JButton("Game 2");
		dbBtnGames[2].setBounds(800, 400, 400, 50);
		frame.add(dbBtnGames[2]);
		
		dbBtnGames[3] = new JButton("Game 3");
		dbBtnGames[3].setBounds(800, 450, 400, 50);
		frame.add(dbBtnGames[3]);
		
		dbBtnGames[4] = new JButton("Game 4");
		dbBtnGames[4].setBounds(800, 500, 400, 50);
		frame.add(dbBtnGames[4]);
		
		
		frame.setSize(1920,1080);//400 width and 500 height
		frame.setLayout(null);//using no layout managers
		frame.setVisible(true);//making the frame visible
    }


    public void show_results()
    {
        //for (int x = 0; x < dbGuiResults.length; x++)
    	//    DestroyImmediate(dbGuiResults[x].gameObject);
    	//dbGuiResults.Clear();
    	List<SubGame> dbCheckWishlist = new ArrayList<>(Arrays.asList(user.dbGamesWishlist));
    	List<SubGame> dbCheckRemoved = new ArrayList<>(Arrays.asList(user.dbGamesRemoved));


        SubGame dbPotentialGames[] = new SubGame[1000];
        int numPotentials = 0;

        for (int x = 0; x < user.dbTags.length; x++)
        {
            for (int y = 0; y < api.dbGames.length; y++)
            {
                //if (!dbPotentialGames.Contains(api.dbGames[y]) && !user.dbGamesWishlist.Contains(api.dbGames[y]) && !user.dbGamesRemoved.Contains(api.dbGames[y]))
            	List<SubGame> dbCheck = new ArrayList<>(Arrays.asList(dbPotentialGames));
            	if (!dbCheck.contains(api.dbGames[y]) && !dbCheckWishlist.contains(api.dbGames[y]) && !dbCheckRemoved.contains(api.dbGames[y]))
                {
                    //If game is not in either wishlist or trash//
                    for (int z = 0; z < api.dbGames[y].dbTags.length; z++)
                    {
                        if (user.dbTags[x].tag == api.dbGames[y].dbTags[z].tag)
                        {
                        	//dbPotentialGames.Add(api.dbGames[y]);
                        	dbPotentialGames[numPotentials] = api.dbGames[y];
                        	numPotentials++;
                            break;
                        }
                    }
                }
            }
        }

        //Modify rating by tags//
        for (int x = 0; x < dbPotentialGames.length; x++)
        {
            for (int y = 0; y < dbPotentialGames[x].dbTags.length; y++)
            {
                for (int z = 0; z < user.dbTags.length; z++)
                {
                    var mod = 1;
                    if (dbPotentialGames[x].dbTags[y].tag == user.dbTags[z].tag)
                    {
                        mod = Math.round(user.dbTags[z].val * 0.5f);
                        dbPotentialGames[x].rating += mod;
                    }
                }
            }
        }


        //tohs.db_morphs = tohs.db_morphs.OrderBy(w => (w.delay + w.dur)).ToList();
        //dbPotentialGames = dbPotentialGames.OrderBy(w => w.rating).ToList();
        Arrays.sort(dbPotentialGames);

        //int num = dbPotentialGames.length;
        //num = Math.Clamp(num, 0, 5);
        for (int x = 0; x < 5; x++)
        {
            //var tgo = (GameObject) Instantiate(prefab_gui_result, prefab_gui_result.transform.position, prefab_gui_result.transform.rotation, prefab_gui_result.transform.parent);
        	//var gres = tgo.GetComponent<gui_result>();
        	//gres.txt_nam.text = dbPotentialGames[x].nam;
        	//gres.game_s = dbPotentialGames[x];
        	//db_gui_results.Add(gres);
        	//tgo.SetActive(true);
        	dbBtnGames[x].setText(dbPotentialGames[x].nam);
        }
    }
    
    
    
    public boolean contains()
    {
    	
    	return false;
    }


    public void set_question()
    {
    	txtQuestion.setText(dbQuestions[qnum].quest);

        //**Clear Old Choices**//
        for (int x = 0; x < dbGuiChoices.length; x++)
            //dbGuiChoices[x].dbTags.Clear();
        {
        	for (int y = 0; y < dbGuiChoices[x].dbTags.length; y++)
        	{
        		dbGuiChoices[x].dbTags[y].tag = "";
        		dbGuiChoices[x].dbTags[y].val = 0;
        	}
        	dbGuiChoices[x].num = 0;
        }
        

        //**Add New Choices**//
        for (int x = 0; x < dbQuestions[qnum].dbChoices.length; x++)
        {
			//dbGuiChoices[x].txt_choice.text = dbQuestions[qnum].dbChoices[x].choice;
        	dbBtnAnswers[x].setText(dbQuestions[qnum].dbChoices[x].choice);

        	for (int y = 0; y < dbQuestions[qnum].dbChoices[x].dbTags.length; y++)
            {
                var ntag = new SubTag();
                ntag.tag = dbQuestions[qnum].dbChoices[x].dbTags[y].tag;
                ntag.val = dbQuestions[qnum].dbChoices[x].dbTags[y].val;
                
                //dbGuiChoices[x].dbTags.Add(ntag);
                dbGuiChoices[x].dbTags[dbGuiChoices[x].num] = ntag;
                dbGuiChoices[x].num++;
            }
        }
    }


    public void gui_choice_selected(GuiChoice tgchoice)
    {
        for (int x = 0; x < tgchoice.dbTags.length; x++)
            user.add_choice(tgchoice.dbTags[x].tag, tgchoice.dbTags[x].val);
        qnum++;

        if (qnum >= dbQuestions.length) //Out of questions//
            qnum = 0;

        show_results();
        set_question();
    }


    public void btn_add_game(GuiResult tgresult)
    {
        //user.dbGamesWishlist.Add(tgresult.game_s);
        user.dbGamesWishlist[user.numWishlist] = tgresult.game_s;
        user.numWishlist++;
        //tgresult.state = "moving"; //Animation game being added to profile/wishlist//
        //StartCoroutine(delayed_show_results(1));
        show_results();
    }


    public void btn_remove_game(GuiResult tgresult)
    {
        //user.dbGamesRemoved.Add(tgresult.game_s);
        user.dbGamesRemoved[user.numRemoved] = tgresult.game_s;
        user.numRemoved++;
        //tgresult.state = "deleting"; //Animation game being deleted//
        //StartCoroutine(delayed_show_results(1));
        show_results();
    }
}
