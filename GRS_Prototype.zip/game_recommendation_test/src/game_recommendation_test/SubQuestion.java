package game_recommendation_test;
//import java.util.*;
import java.util.List;


public class SubQuestion
{
    public String choice;
    public SubTag[] dbTags = new SubTag[100];
}
