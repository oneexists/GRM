package game_recommendation_test;
import java.util.List;


public class SubGame
{
    public String nam;
    public float rating;
    public SubTag[] dbTags = new SubTag[100];
}
