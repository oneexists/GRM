package game_recommendation_test;
import java.util.List;


public class ApiManager
{
    public SubGame[] dbGames = new SubGame[100];
}
