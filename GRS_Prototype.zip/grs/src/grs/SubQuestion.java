package grs;


public class SubQuestion
{
    public String choice;
    public List<SubTag> dbTags;
}
