package grs;


public class SubTag
{
    public String tag;
    public int val;
}
