package grs;


public class SubGame
{
    public String nam;
    public float rating;
    public List<SubTag> db_tags;
}
