package grs;


public class ApiManager
{
    public List<SubGame> dbGames;
}
