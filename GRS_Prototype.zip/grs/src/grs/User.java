package grs;


public class User
{
    public List<SubGame> dbGamesWishlist;
    public List<SubGame> dbGamesRemoved;
    public List<SubTag> dbTags;


    public void add_choice(String ttag, int val)
    {
        boolean included = false;
        for (int x = 0; x < dbTags.Count; x++)
        {
            if (dbTags[x].tag == ttag)
            {
                included = true;
                dbTags[x].val += val;
                break;
            }
        }

        if (!included)
        {
            var ntag = new SubTag();
            ntag.tag = ttag;
            ntag.val = val;
            dbTags.Add(ntag);
        }
    }
}
