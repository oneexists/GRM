package grs;


public class GuiManager
{
    public List<GameObject> dbGuiGos;


    public void activate_gui(int num)
    {
        for (int x = 0; x < dbGuiGos.Count; x++)
            dbGuiGos[x].SetActive(false);

        dbGuiGos[num].SetActive(true);
    }
}
