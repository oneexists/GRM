package grs;


public class GuiChoice
{
    public Text txt_choice;
    public List<SubTag> dbTags;
}
