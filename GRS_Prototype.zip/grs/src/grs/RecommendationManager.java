package grs;


public class RecommendationManager
{
    public int qnum;
    public User user_s;
    public ApiManager api;
    public Text txtQuestion;
    public Text txtResults;
    public GameObject prefab_gui_result;
    public List<GameObject> dbGos;
    public List<GuiChoice> dbGuiChoices;
    public List<Question> dbQuestion;
    public List<GuiResult> dbGuiResults;


    void show_results()
    {
        for (int x = 0; x < dbGuiResults.Count; x++)
            DestroyImmediate(dbGuiResults[x].gameObject);
        dbGuiResults.Clear();

        List<SubGame> db_potential_games = new List<SubGame>();

        for (int x = 0; x < user_s.dbTags.Count; x++)
        {
            for (int y = 0; y < api.db_games.Count; y++)
            {
                if (!db_potential_games.Contains(api.dbGames[y]) && !user_s.dbGamesWishlist.Contains(api.dbGames[y]) && !user_s.dbGamesRemoved.Contains(api.dbGames[y]))
                {
                    //If game is not in either wishlist or trash//
                    for (int z = 0; z < api.dbGames[y].db_tags.Count; z++)
                    {
                        if (user_s.dbTags[x].tag == api.dbGames[y].db_tags[z].tag)
                        {
                            db_potential_games.Add(api.dbGames[y]);
                            break;
                        }
                    }
                }
            }
        }

        //Modify rating by tags//
        for (int x = 0; x < db_potential_games.Count; x++)
        {
            for (int y = 0; y < db_potential_games[x].db_tags.Count; y++)
            {
                for (int z = 0; z < user_s.db_tags.Count; z++)
                {
                    var mod = 1;
                    if (db_potential_games[x].db_tags[y].tag == user_s.db_tags[z].tag)
                    {
                        mod = Mathf.RoundToInt(user_s.db_tags[z].val * 0.5f);
                        db_potential_games[x].rating += mod;
                    }
                }
            }
        }


        //tohs.db_morphs = tohs.db_morphs.OrderBy(w => (w.delay + w.dur)).ToList();
        db_potential_games = db_potential_games.OrderBy(w => w.rating).ToList();

        int num = db_potential_games.Count;
        num = Mathf.Clamp(num, 0, 5);
        for (int x = 0; x < num; x++)
        {
            var tgo = (GameObject) Instantiate(prefab_gui_result, prefab_gui_result.transform.position, prefab_gui_result.transform.rotation, prefab_gui_result.transform.parent);
            var gres = tgo.GetComponent<gui_result>();
            gres.txt_nam.text = db_potential_games[x].nam;
            gres.game_s = db_potential_games[x];
            db_gui_results.Add(gres);
            tgo.SetActive(true);
        }
    }


    void set_question()
    {
        txt_question.text = db_questions[qnum].quest;

        //**Clear Old Choices**//
        for (int x = 0; x < db_gui_choices.Count; x++)
            db_gui_choices[x].db_tags.Clear();

        //**Add New Choices**//
        for (int x = 0; x < db_questions[qnum].db_choices.Count; x++)
        {
            db_gui_choices[x].txt_choice.text = db_questions[qnum].db_choices[x].choice;
            for (int y = 0; y < db_questions[qnum].db_choices[x].db_tags.Count; y++)
            {
                var ntag = new sub_tag();
                ntag.tag = db_questions[qnum].db_choices[x].db_tags[y].tag;
                ntag.val = db_questions[qnum].db_choices[x].db_tags[y].val;
                db_gui_choices[x].db_tags.Add(ntag);
            }
        }
    }


    public void gui_choice_selected(gui_choice tgchoice)
    {
        for (int x = 0; x < tgchoice.db_tags.Count; x++)
            user_s.add_choice(tgchoice.db_tags[x].tag, tgchoice.db_tags[x].val);
        qnum++;

        if (qnum >= db_questions.Count) //Out of questions//
            qnum = 0;

        show_results();
        set_question();
    }


    IEnumerator delayed_show_results(float delay)
    {
        yield return new WaitForSeconds(delay);

        show_results();
    }


    public void btn_add_game(gui_result tgresult)
    {
        user_s.db_games_wishlist.Add(tgresult.game_s);
        tgresult.state = "moving"; //Animation game being added to profile/wishlist//
        StartCoroutine(delayed_show_results(1));
    }


    public void btn_remove_game(gui_result tgresult)
    {
        user_s.db_games_removed.Add(tgresult.game_s);
        tgresult.state = "deleting"; //Animation game being deleted//
        StartCoroutine(delayed_show_results(1));
    }


    void OnEnable()
    {
        set_question();
    }
}
