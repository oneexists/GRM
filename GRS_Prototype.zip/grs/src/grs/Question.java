package grs;


public class Question
{
    public String quest;
    public List<SubQuestion> dbChoices;
}
